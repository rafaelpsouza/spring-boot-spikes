# Load up the stdlib
. ${SCRIPTPACK_STDLIB_ROOT}/main.sh

# Our own functions
. ${SCRIPTPACK_JAVA_ROOT}/install.sh
